<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" value="<?php echo e(csrf_token()); ?>" />
        <title>Inqilabi Farm Standalone</title>
        <link href="<?php echo e(mix('css/app.css')); ?>" type="text/css" rel="stylesheet" />
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fancyapps/ui/dist/fancybox.css"/>
    </head>
    <body>
        <div id="app"></div>
        <script src="<?php echo e(mix('js/app.js')); ?>" type="text/javascript"></script>
        <script src="https://cdn.jsdelivr.net/npm/@fancyapps/ui/dist/fancybox.umd.js"></script>
    </body>
</html><?php /**PATH E:\PROJECT\INQILABI\INQILABI FARM\inqilabi_farm_standalone\resources\views/welcome.blade.php ENDPATH**/ ?>